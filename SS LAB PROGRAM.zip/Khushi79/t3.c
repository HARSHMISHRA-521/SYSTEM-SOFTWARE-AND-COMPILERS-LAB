#include<stdio.h>
#include<stdlib.h>
#include<string.h>
char table[10][10]={"NT","a","b","A","aBa","Error","B","@","bB"};
char buffer[10],stack[10];
int top=-1;

char pop(){
    return stack[top--];
}

void push(int e){
    stack[++top]=e;
}

void display(){
    for(int i=top;i>=0;i--)
        printf("%c",stack[i]);
	printf("\n");
}

char *parse_table(char stacktop, char inputval){
	switch(stacktop)
	{
		case 'A':switch(inputval){
case 'a': return table[4];
case 'b': return table[5];
}
break;
case 'B':switch(inputval){
case 'a': return table[7];
case 'b': return table[8];
}
	}
}
int main(){
	char *str;
int i=0,ptr=0;
printf("Enter the String : ");
scanf("%s",buffer);
if(buffer[strlen(buffer)-1]!=';')
{
printf("String must end with a ;\n");
exit(0);
} 
push('$');
push('A');
while(stack[top]!='$'&& (ptr<strlen(buffer))){
	if(stack[top]==buffer[ptr]){
ptr++;
printf("1. Element popped is %c \n",pop());
}
else if(stack[top]=='@')
printf("2. Element popped is %c \n",pop());
else
{
	str=parse_table(stack[top],buffer[ptr]);
if(strcmp(str,"error")==0){
	printf("Error has occurred\n");
break;
}
printf("3. Element popped is %c \n",pop());
for(i=strlen(str)-1;i>=0;i--)
push(*(str+i));
}
display();
}
if(stack[top]=='$'&& buffer[ptr]==';')
printf("accepted\n");
else
printf("not accepted\n");
	return 0;
}
