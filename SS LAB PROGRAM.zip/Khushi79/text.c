/*this is the 1st comment*/
//this is the 2nd comment
int main(){
printf("Hello World");
}
//this is the 3rd comment

